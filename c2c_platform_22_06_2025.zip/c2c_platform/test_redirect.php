<?php
require_once 'config.php';
var_dump($_SESSION);